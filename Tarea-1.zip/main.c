#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

void limpiarBuffer() {
  int c;
  while ((c = getchar()) != '\n' && c != EOF) {}
}

// Función para registrar un nuevo paciente
void registrar_paciente(List *pacientes) {
  printf("Registrar nuevo paciente\n\n");
  char nombre[50];
  int edad;
  char sintomas[100];

  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]", nombre);
  
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &edad);

  printf("Ingrese los síntomas del paciente: ");
  scanf(" %[^\n]", sintomas);
  
  // Crear un nuevo paciente
  Paciente *nuevo_paciente = (Paciente *)malloc(sizeof(Paciente));
  if(nuevo_paciente == NULL){
    printf("Error al asignar memoria para el paciente.\n");
    free(nuevo_paciente);
    return;
  }
  // Asignar los datos del paciente
  strcpy(nuevo_paciente->nombre, nombre);
  nuevo_paciente->edad = edad;
  strcpy(nuevo_paciente->sintomas, sintomas);
  time_t tiempo_actual = time(NULL);
  nuevo_paciente->fecha_registro = tiempo_actual;
  nuevo_paciente->prioridad = Bajo;
  list_pushBack(pacientes, nuevo_paciente);
}

// Función para ordenar pacientes por prioridad y fecha de registro
void ordenar_pacientes(List *pacientes){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  int intercambios = 0;

  do {
    intercambios = 0;
    Node *current = pacientes->head;
    while (current->next != NULL){
      Paciente *paciente_actual = (Paciente *)current->data;
      Paciente *paciente_siguiente = (Paciente *)current->next->data;

      // Comparar prioridad y fecha de registro para ordenar
      if(paciente_actual->prioridad > paciente_siguiente->prioridad || (paciente_actual->prioridad == paciente_siguiente->prioridad 
        && paciente_actual->fecha_registro > paciente_siguiente->fecha_registro)) {

        // Intercambiar los pacientes
        void *temp = current->data;
        current->data = current->next->data;
        current->next->data= temp;
        intercambios++;
      }
        current= current->next;
    }
  } while (intercambios);
}

// Función para asignar prioridad a un paciente existente
void asignar_prioridad_paciente(List *pacientes) {
    if (list_isEmpty(pacientes)) {
      printf("No hay pacientes registrados.\n");
      return;
    }

    char nombre[50];
    printf("Ingrese el nombre del paciente: ");
    scanf(" %[^\n]", nombre);

    Node *actual = pacientes->head;
    while (actual != NULL) {
        Paciente *paciente = (Paciente *)actual->data;
        if (strcmp(paciente->nombre, nombre) == 0) {
            printf("\nSeleccione el nuevo nivel de prioridad:\n");
            printf("\nEl paciente: %s tiene prioridad %s\n\n", paciente->nombre, paciente->prioridad == Alto ? "Alto" : paciente->prioridad == Medio ? "Medio" : "Bajo");
            printf("\n1) Alto\n");
            printf("2) Medio\n");
            printf("3) Bajo\n");
            int opcion;
            do {
                printf("Ingrese su opción: ");
                scanf("%d", &opcion);
                switch (opcion) {
                    case 1:
                        paciente->prioridad = Alto;
                        printf("La prioridad del paciente %s ha sido actualizada a Alto.\n", paciente->nombre);
                        break;
                    case 2:
                        paciente->prioridad = Medio;
                        printf("La prioridad del paciente %s ha sido actualizada a Medio.\n", paciente->nombre);
                        break;
                    case 3:
                        paciente->prioridad = Bajo;
                        printf("La prioridad del paciente %s ha sido actualizada a Bajo.\n", paciente->nombre);
                        break;
                    default:
                        printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
                }
            } while (opcion < 1 || opcion > 3);
            return;
        }
        actual = actual->next;
    }

    printf("El paciente %s no ha sido encontrado.\n", nombre);
}

// Función para mostrar la lista de pacientes en espera
void mostrar_lista_pacientes(List *pacientes) {
  if (list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  
  ordenar_pacientes(pacientes);
  
  printf("\nPacientes en espera: \n\n");
  void *paciente = list_first(pacientes);
  int contador = 1;
  while (paciente != NULL){
    Paciente *paciente_actual = (Paciente *)paciente;
    printf("%d) Nombre: %s\n   Edad: %d\n   Síntomas: %s\n   Fecha de registro: %s   Prioridad: %s\n\n", contador, 
    paciente_actual->nombre, paciente_actual->edad, paciente_actual->sintomas, ctime(&paciente_actual->fecha_registro), 
    paciente_actual->prioridad == Alto ? "Alto" : paciente_actual->prioridad == Medio ? "Medio" : "Bajo" );
    
    paciente = list_next(pacientes);
    contador++;
  }
}

// Función para filtrar y mostrar pacientes por prioridad
void filtrar_pacientes_por_prioridad(List *pacientes, int prioridad){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  void *paciente = list_first(pacientes);
  int contador = 1;
  while (paciente != NULL){
    Paciente *paciente_actual = (Paciente *)paciente;
    if(paciente_actual->prioridad == prioridad){
      printf("%d) Nombre: %s\n   Edad: %d\n   Síntomas %s\n   Fecha de registro: %s   Prioridad: %s\n\n", contador, 
      paciente_actual->nombre, paciente_actual->edad, paciente_actual->sintomas, ctime(&paciente_actual->fecha_registro), 
      paciente_actual->prioridad == Alto ? "Alto" : paciente_actual->prioridad == Medio ? "Medio" : "Bajo" );
      contador++;
    }
    paciente= list_next(pacientes);
  }
}

// Función para atender al siguiente paciente en la lista de espera
void atender_siguiente_paciente(List *pacientes){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }

  ordenar_pacientes(pacientes);

  // Sacar al siguiente paciente de la lista
  Paciente *paciente_actual = (Paciente *)list_popFront(pacientes);

  printf("Paciente a atender: \n\n");
  printf("Nombre: %s\n", paciente_actual->nombre);
  printf("Edad: %d\n", paciente_actual->edad);
  printf("Síntomas: %s\n", paciente_actual->sintomas);
  printf("Fecha de registro: %s", ctime(&paciente_actual->fecha_registro));
  printf("Prioridad: %s\n", paciente_actual->prioridad == Alto ? "Alto" : paciente_actual->prioridad == Medio ? "Medio" : "Bajo");
  free(paciente_actual);
}

// Función para mostrar pacientes filtrados por prioridad
void mostrar_pacientes_por_prioridad(List *pacientes){
  if (list_isEmpty(pacientes)) {
    printf("No hay pacientes registrados.\n");
    return;
  }

  ordenar_pacientes(pacientes);
  
  int opcion;
  do {
    printf("Seleccione la prioridad de pacientes a mostrar:\n\n");
    printf("1) Alto\n");
    printf("2) Medio\n");
    printf("3) Bajo\n");
    
    printf("Ingrese su opción: ");
    if (scanf("%d", &opcion) != 1) {
      printf("Por favor, ingrese un número.\n");
      limpiarBuffer();
      continue;
    } 

    if(opcion < 1 || opcion > 3) {
      printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
      limpiarBuffer();
      continue;
    }

    switch (opcion) {
      case 1:
        filtrar_pacientes_por_prioridad(pacientes, Alto);
        break;
      case 2:
        filtrar_pacientes_por_prioridad(pacientes, Medio);
        break;
      case 3:
        filtrar_pacientes_por_prioridad(pacientes, Bajo);
        break;
      default:
        printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
    } 
  } while (opcion < 1 || opcion > 3);
}

// Función principal
int main(){
  int opcion;
  List *pacientes = list_create();
  
  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf("%d", &opcion);

    while (getchar() != '\n');

    switch (opcion) {
    case 1:
      registrar_paciente(pacientes);
      break;
    case 2:
      asignar_prioridad_paciente(pacientes);
      break;
    case 3:
      mostrar_lista_pacientes(pacientes);
      break;
    case 4:
      atender_siguiente_paciente(pacientes);
      break;
    case 5:
      mostrar_pacientes_por_prioridad(pacientes);
      break;
    case 6:
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != 6);
  list_clean(pacientes); // Limpiar la memoria asignada a la lista de pacientes
  return 0;
}

