#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

void presioneTeclaParaContinuar() {
  puts("Presione una tecla para continuar...");
  getchar(); // Consume el '\n' del buffer de entrada
  getchar(); // Espera a que el usuario presione una tecla
}

// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir");
}

void limpiarBuffer() {
  int c;
  while ((c = getchar()) != '\n' && c != EOF) {}
}

void registrar_paciente(List *pacientes) {
  printf("Registrar nuevo paciente\n\n");
  char nombre[50];
  int edad;
  char sintomas[100];
  
  printf("Ingrese el nombre del paciente: ");
  scanf(" %[^\n]", nombre);
  printf("Ingrese la edad del paciente: ");
  scanf("%d", &edad);

  printf("Ingrese los síntomas del paciente: ");
  scanf(" %[^\n]", sintomas);
  
  Paciente *nuevo_paciente = (Paciente *)malloc(sizeof(Paciente));
  if(nuevo_paciente == NULL){
    printf("Error al asignar memoria para el paciente.\n");
    free(nuevo_paciente);
    return;
  }
  strcpy(nuevo_paciente->nombre, nombre);
  nuevo_paciente->edad = edad;
  strcpy(nuevo_paciente->sintomas, sintomas);
  time_t tiempo_actual = time(NULL);
  nuevo_paciente->fecha_registro = tiempo_actual;
  nuevo_paciente->prioridad = Bajo;
  list_pushBack(pacientes, nuevo_paciente);
}

void ordenar_pacientes(List *pacientes){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  int intercambios = 0;

  do {
    intercambios = 0;
    Node *current = pacientes->head;
    while (current->next != NULL){
      Paciente *paciente_actual = (Paciente *)current->data;
      Paciente *paciente_siguiente = (Paciente *)current->next->data;

      if(paciente_actual->prioridad < paciente_siguiente->prioridad || (paciente_actual->prioridad == paciente_siguiente->prioridad 
        && paciente_actual->fecha_registro < paciente_siguiente->fecha_registro)) {
        // Intercambiar los pacientes
        void *temp = current->data;
        current->data = current->next->data;
        current->next->data= temp;
        intercambios++;
      }
        current= current->next;
    }
  } while (intercambios);
}

void asignar_prioridad_paciente(List *pacientes) {
    if (list_isEmpty(pacientes)) {
        printf("No hay pacientes registrados.\n");
        return;
    }

    char nombre[50];
    printf("Ingrese el nombre del paciente: ");
    scanf(" %[^\n]", nombre);

    Node *actual = pacientes->head;
    while (actual != NULL) {
        Paciente *paciente = (Paciente *)actual->data;
        if (strcmp(paciente->nombre, nombre) == 0) {
            printf("\nSeleccione el nuevo nivel de prioridad:\n");
            printf("\nEl paciente: %s tiene prioridad %s\n\n", paciente->nombre, paciente->prioridad == Alto ? "Alto" : paciente->prioridad == Alto ? "Alto" : "Medio");
            printf("\n1) Alto\n");
            printf("2) Medio\n");
            printf("3) Bajo\n");
            int opcion;
            do {
                printf("Ingrese su opción: ");
                scanf("%d", &opcion);
                switch (opcion) {
                    case 1:
                        paciente->prioridad = Alto;
                        printf("La prioridad del paciente %s ha sido actualizada a Alto.\n", paciente->nombre);
                        break;
                    case 2:
                        paciente->prioridad = Medio;
                        printf("La prioridad del paciente %s ha sido actualizada a Medio.\n", paciente->nombre);
                        break;
                    case 3:
                        paciente->prioridad = Bajo;
                        printf("La prioridad del paciente %s ha sido actualizada a Bajo.\n", paciente->nombre);
                        break;
                    default:
                        printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
                }
            } while (opcion < 1 || opcion > 3);
            return; // Salir de la función después de actualizar la prioridad
        }
        actual = actual->next;
    }

    printf("El paciente %s no ha sido encontrado.\n", nombre);
}

void mostrar_lista_pacientes(List *pacientes) {
  if (list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  // Mostrar pacientes en la cola de espera
  printf("\nPacientes en espera: \n\n");
  void *paciente = list_first(pacientes);
  int contador = 1;
  while (paciente != NULL){
    Paciente *paciente_actual = (Paciente *)paciente;
    printf("%d) Nombre: %s\n   Edad: %d\n   Síntomas: %s\n   Fecha de registro: %s   Prioridad: %s\n\n", contador, 
    paciente_actual->nombre, paciente_actual->edad, paciente_actual->sintomas, ctime(&paciente_actual->fecha_registro), 
    paciente_actual->prioridad == Alto ? "Alto" : paciente_actual->prioridad == Medio ? "Medio" : "Bajo" );
    paciente = list_next(pacientes);
    contador++;
  }
}

void filtrar_pacientes_por_prioridad(List *pacientes, int prioridad){
  if(list_isEmpty(pacientes)){
    printf("No hay pacientes registrados.\n");
    return;
  }
  void *paciente = list_first(pacientes);
  int contador = 1;
  while (paciente != NULL){
    Paciente *paciente_actual = (Paciente *)paciente;
    if(paciente_actual->prioridad == prioridad){
      printf("%d) Nombre: %s\n   Edad: %d\n   Síntomas %s\n   Fecha de registro: %s   Prioridad: %s\n\n", contador, 
      paciente_actual->nombre, paciente_actual->edad, paciente_actual->sintomas, ctime(&paciente_actual->fecha_registro), 
      paciente_actual->prioridad == Alto ? "Alto" : paciente_actual->prioridad == Medio ? "Medio" : "Bajo" );
      contador++;
    }
    paciente= list_next(pacientes);
  }
}

void mostrar_pacientes_por_prioridad(List *pacientes){
  if (list_isEmpty(pacientes)) {
    printf("No hay pacientes registrados.\n");
    return;
  }
  
  int opcion;
  do {
    printf("Seleccione la prioridad de pacientes a mostrar:\n\n");
    printf("1) Alto\n");
    printf("2) Medio\n");
    printf("3) Bajo\n");
    
    printf("Ingrese su opción: ");
    if (scanf("%d", &opcion) != 1) {
      printf("Por favor, ingrese un número.\n");
      limpiarBuffer();
      continue;
    } 

    if(opcion < 1 || opcion > 3) {
      printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
      limpiarBuffer();
      continue;
    }

    switch (opcion) {
      case 1:
        filtrar_pacientes_por_prioridad(pacientes, Alto);
        break;
      case 2:
        filtrar_pacientes_por_prioridad(pacientes, Medio);
        break;
      case 3:
        filtrar_pacientes_por_prioridad(pacientes, Bajo);
        break;
      default:
        printf("Opción no válida. Por favor, ingrese un número entre 1 y 3.\n");
    } 
  } while (opcion < 1 || opcion > 3);
}


int main(){
  int opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %d", &opcion);

    switch (opcion) {
    case 1:
      registrar_paciente(pacientes);
      break;
    case 2:
      asignar_prioridad_paciente(pacientes);
      break;
    case 3:
      ordenar_pacientes(pacientes);
      mostrar_lista_pacientes(pacientes);
      break;
    case 4:
      // Lógica para atender al siguiente paciente
      break;
    case 5:
      ordenar_pacientes(pacientes);
      mostrar_pacientes_por_prioridad(pacientes);
      break;
    case 6:
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

  } while (opcion != 6);
  list_clean(pacientes);
  return 0;
}

